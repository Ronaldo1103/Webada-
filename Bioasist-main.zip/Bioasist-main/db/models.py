from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, LargeBinary, Enum as SQLEnum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
from enum import Enum as PyEnum
# Importamos timezone para marcas de tiempo con manejo de zona horaria (UTC)
from datetime import timezone
from sqlalchemy import Column, Integer, String, DateTime
from .base import Base 
import pytz
from datetime import datetime

zona_lima = pytz.timezone("America/Lima")
# Definimos un Enum de Python para los roles, más fácil de usar en FastAPI/Pydantic
class UserRole(PyEnum):
    admin = "admin"
    practicante = "practicante"


# =============================================================
# TABLAS DE AUTENTICACIÓN Y ROLES
# =============================================================

# Si tu autenticación usa un sistema simple de roles, la tabla 'Role' es redundante.
# Si quieres mantener el Role con relación FK, es correcto, pero lo simplifico
# para coincidir con un flujo de autenticación estándar de FastAPI/Pydantic.

class Usuario(Base):
    __tablename__ = "usuarios"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True)
    password = Column(String(255))
    
    # 🚨 ESTO DEBE COINCIDIR CON LA BASE DE DATOS
    # Antes tenías: rol = Column(ENUM(Role))
    # Ahora debe ser:
    role_id = Column(Integer, default=2) # 2 = Practicante, 1 = Admin
    
    # ... (Otros campos)
    # Si quisieras mantener la tabla Role:
    # role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    # rol_ref = relationship("Role", back_populates="usuarios") # Renombrado
    
# Si no usas la tabla `Role` para otra cosa, puedes eliminarla.
# class Role(Base):
#     ...

# =============================================================
# TABLA DE ENTIDADES DE NEGOCIO (UNIVERSIDADES)
# =============================================================
class UniversidadModel(Base):
    __tablename__ = "universidades"
    
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(255), unique=True, index=True, nullable=False)
    siglas = Column(String(50))
    # 🚨 CORRECCIÓN: Usar datetime.now(timezone.utc) para marcas de tiempo conscientes de la zona horaria
    fecha_registro = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    practicantes = relationship("PracticanteDB", back_populates="universidad")


# =============================================================
# ESTRUCTURA BIOMÉTRICA
# =============================================================

# 1. Practicantes (Modificado para incluir FK de Universidad y un solo nombre)
class PracticanteDB(Base):
    __tablename__ = "practicantes"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(255), nullable=False)
    apellido = Column(String(255), nullable=True)
    email = Column(String(255), unique=True, index=True)
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    universidad_id = Column(Integer, ForeignKey("universidades.id"), nullable=False)

    universidad = relationship("UniversidadModel", back_populates="practicantes")
    rostros = relationship("RostroBiometricoModel", back_populates="practicante")
    asistencias = relationship("Asistencia", back_populates="practicante")


# 2. Historial Biométrico (Auditabilidad)
class HistorialBiometricoModel(Base):
    __tablename__ = "historial_biometrico"

    id = Column(Integer, primary_key=True, index=True)
    nombre_sugerido = Column(String(255), nullable=False)
    
    # Dato BLOB para la imagen original (Auditoría)
    imagen_original = Column(LargeBinary, nullable=False) 
    
    # Dato BLOB para el vector
    vector_biometrico = Column(LargeBinary, nullable=False) 
    
    fecha_registro = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    
    # Relación que se usa para verificar si el rostro ya fue aprobado
    rostro_aprobado = relationship(
        "RostroBiometricoModel", 
        back_populates="historial_origen", 
        uselist=False # Un Historial solo puede generar un Rostro aprobado
    )


# 3. Rostros Biométricos (Vector activo para matching)
class RostroBiometricoModel(Base):
    __tablename__ = "rostros_biometricos"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # FK 1: Dueño del rostro
    practicante_id = Column(Integer, ForeignKey('practicantes.id'), nullable=False)
    
    # NUEVO FK 2: Origen de auditoría (Debe ser ÚNICO)
    historial_id = Column(Integer, ForeignKey("historial_biometrico.id"), nullable=False)

    # Vector duplicado para matching rápido (evitar joins)
    vector_biometrico = Column(LargeBinary, nullable=False) 
    fecha_registro = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relaciones:
    practicante = relationship("PracticanteDB", back_populates="rostros")
    historial_origen = relationship("HistorialBiometricoModel", back_populates="rostro_aprobado")


# =============================================================
# ASISTENCIAS
# =============================================================
class Asistencia(Base):
    __tablename__ = "asistencias"

    id = Column(Integer, primary_key=True, index=True)
    practicante_id = Column(Integer, ForeignKey('practicantes.id'), nullable=False)
    timestamp_evento = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    #timestamp_evento = Column(DateTime, default=lambda: datetime.now(zona_lima))
    tipo_evento = Column(String(50), nullable=False) # 'entrada' o 'salida'

    practicante = relationship("PracticanteDB", back_populates="asistencias")

