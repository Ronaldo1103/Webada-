from pydantic import BaseModel

# Esquema usado para crear un nuevo registro (Input)
class PracticanteSchema(BaseModel):
    nombre: str
    codigo_biometrico: str # El vector (embedding) como string

# Esquema usado para la respuesta de la API (Output)
# Debe coincidir con los campos del modelo ORM (PracticanteDB)
class PracticanteResponse(BaseModel):
    id: int
    nombre: str
    # Opcional: puedes excluir el código biométrico por seguridad si no es necesario en la respuesta
    # codigo_rostro: str 

    class Config:
        from_attributes = True # Reemplaza orm_mode = True en Pydantic v2+
