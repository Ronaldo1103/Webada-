# Backend - En la carpeta db/: mi_backend/db/database.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .base import Base 

# ⚠️ REEMPLAZA LOS VALORES CON TU CONFIGURACIÓN DE MARIADB
DATABASE_URL = "mysql+pymysql://root:995947471@localhost/BioasisDB"


engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Función para crear las tablas al iniciar el servidor (si no existen)
def create_tables():
    # 🔑 CAMBIO CLAVE: Agregamos checkfirst=True
    Base.metadata.create_all(bind=engine, checkfirst=True)

# Función de inyección de dependencia para FastAPI
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()