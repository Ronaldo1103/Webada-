# En: routers/face_recognition.py
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from services import face_service
from db.database import get_db 

router = APIRouter(
    prefix="/face",
    tags=["Reconocimiento Facial"]
)

@router.post("/identify_frame")
def identificar_rostro_en_vivo(
    imagen: UploadFile = File(...), # La imagen (frame) enviada por Flutter
    db: Session = Depends(get_db)
):
    """
    Recibe un frame de la cámara, identifica el rostro y devuelve el nombre.
    """
    try:
        contenido_imagen = imagen.file.read()
    except Exception:
        raise HTTPException(status_code=500, detail="Error al leer la imagen.")
    finally:
        imagen.file.close()

    # 1. Extraer el código biométrico del frame con MobileNet
    codigo_rostro_nuevo = face_service.extraer_codigo_biometrico(
        contenido_imagen, 
        modelo="MobileNet"
    )

    # 2. Comparar el código nuevo con toda la tabla 'practicantes'
    resultado = face_service.buscar_coincidencia_rapida(
        db, 
        codigo_rostro_nuevo
    )

    if resultado:
        # Si encuentra un practicante con una distancia baja
        return {"status": "IDENTIFICADO", "nombre": resultado.nombre, "id": resultado.id}
    else:
        # Si no encuentra coincidencia
        return {"status": "NO_IDENTIFICADO", "nombre": "Desconocido"}