from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
import traceback # <--- Importación clave para depuración (Debugging)
from datetime import datetime
import pytz

from services import practicante_service
from db.database import get_db
from db.models import HistorialBiometricoModel, PracticanteDB
from fastapi.responses import JSONResponse
from db.models import Asistencia # <- Asegúrate de tener este modelo definido
from sqlalchemy.orm import Session, joinedload 
from utils.timezones import utc_to_lima
# ^^^^^^^^^^^^^^^ Asegúrate de que 'joinedload' esté aquí
# Creamos el router principal
router = APIRouter(
    prefix="/practicantes",
    tags=["Practicantes"]
)

zona_lima = pytz.timezone("America/Lima")
ahora = datetime.now(zona_lima)
# ================================
# 1. REGISTRAR ROSTRO EN HISTORIAL
# ================================
@router.post("/registrar_rostro", status_code=status.HTTP_201_CREATED)
def registrar_rostro_en_historial(
    nombre: str = Form(...),
    imagen: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    contenido_imagen = imagen.file.read()
    imagen.file.close()

    try:
        codigo_rostro = practicante_service.extraer_codigo_biometrico(contenido_imagen)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    try:
        db_registro_historial = practicante_service.crear_registro_en_historial(
            db=db,
            nombre=nombre,
            codigo_rostro=codigo_rostro,
            contenido_imagen=contenido_imagen
        )
    except Exception as e:
        # Manejo de error mejorado para debugging
        print(f"Error al guardar en el historial: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Error al guardar en el historial. Verifique logs del servidor.")

    return {
        "mensaje": f"Rostro y nombre sugerido '{nombre}' guardados en el historial.",
        "historial_id": db_registro_historial.id
    }

# =========================================
# 2. ADMIN: VINCULAR ROSTRO A PRACTICANTE
# =========================================
@router.post("/vincular_rostro", status_code=status.HTTP_201_CREATED)
def vincular_rostro(
    practicante_id: int = Form(...),
    historial_id: int = Form(...),
    db: Session = Depends(get_db)
):
    try:
        db_rostro_aprobado = practicante_service.vincular_rostro_a_practicante(
            db=db,
            practicante_id=practicante_id,
            historial_id=historial_id
        )
        return {
            "mensaje": f"Rostro aprobado y vinculado al Practicante ID: {practicante_id}.",
            "rostro_aprobado_id": db_rostro_aprobado.id
        }
    except HTTPException as e:
        raise e
    except Exception as e:
        # Manejo de error mejorado para debugging
        print(f"Error al vincular el rostro: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Error al vincular el rostro. Verifique logs del servidor.")

# =========================================
# 3. ADMIN: OBTENER REGISTROS PENDIENTES
# =========================================
@router.get("/historial_pendientes")
def get_pending_historial(db: Session = Depends(get_db)):
    registros = db.query(HistorialBiometricoModel).order_by(
        HistorialBiometricoModel.fecha_registro.desc()
    ).all()

    lista = [
        {
            "historial_id": r.id,
            "nombre_sugerido": r.nombre_sugerido,
            "fecha_registro": r.fecha_registro.isoformat() if r.fecha_registro else None
        } 
        for r in registros
    ]

    return {"registros": lista}


# =========================================
# 4. ADMIN: LISTA DE PRACTICANTES
# =========================================
@router.get("/lista_practicantes")
def obtener_lista_practicantes(db: Session = Depends(get_db)):
    practicantes = db.query(
        PracticanteDB.id,
        PracticanteDB.nombre,
        PracticanteDB.apellido
    ).all()

    lista_practicantes = [
        {
            "id": p.id,
            "nombre_completo": f"{p.nombre} {p.apellido}"
        }
        for p in practicantes
    ]
    return {"practicantes": lista_practicantes}


# =========================================
# 5. CREAR PRACTICANTE SIN ROSTRO
# =========================================
@router.post("/crear", status_code=status.HTTP_201_CREATED)
def crear_practicante(
    nombre: str = Form(...),
    apellido: str = Form(...),
    universidad_id: int = Form(...),
    db: Session = Depends(get_db)
):
    try:
        nuevo = practicante_service.crear_practicante(
            db=db,
            nombre=nombre,
            apellido=apellido,
            universidad_id=universidad_id
        )
        return {
            "mensaje": "Practicante creado con éxito.",
            "practicante_id": nuevo.id
        }
    except Exception as e:
        # Manejo de error mejorado para debugging
        print(f"Error al crear practicante: {e}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Error al crear practicante. Verifique logs del servidor.")


# =========================================
# 6. APP MÓVIL: COINCIDENCIA DE ROSTRO (MATCH)
# =========================================
@router.post("/match")
def match_practicante_face(
    imagen: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    contenido_imagen = imagen.file.read()
    imagen.file.close()

    try:
        # 1. Extraer el código biométrico del rostro capturado
        codigo_rostro_capturado = practicante_service.extraer_codigo_biometrico(contenido_imagen)
        
        # 2. Buscar la coincidencia en la base de datos
        practicante_match: Optional[PracticanteDB] = practicante_service.encontrar_coincidencia(
            db=db,
            codigo_rostro_capturado=codigo_rostro_capturado
        )

        if practicante_match:
            # 3. Si hay coincidencia, registrar la asistencia
            practicante_service.registrar_asistencia(db, practicante_match.id)
            
            return {
                "coincidencia": True,
                "practicante_id": practicante_match.id,
                "nombre": f"{practicante_match.nombre} {practicante_match.apellido}",
                "mensaje": f"¡Asistencia registrada para {practicante_match.nombre}!"
            }
        else:
            # 4. Si NO hay coincidencia, registrar en el historial para revisión
            practicante_service.crear_registro_en_historial(
                db=db,
                nombre=None, # Nombre sugerido es desconocido
                codigo_rostro=codigo_rostro_capturado,
                contenido_imagen=contenido_imagen # Guardar la imagen para revisión
            )
            
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No se encontró coincidencia biométrica. Imagen guardada para revisión."
            )

    except ValueError as e:
        # Esto ocurre si el modelo no detecta un rostro en la imagen
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail=f"No se detectó un rostro claro. Revise su posición, iluminación o asegúrese de que solo haya un rostro visible. Detalle técnico: {str(e)}"
        )
    except Exception as e:
        # CUALQUIER OTRA EXCEPCIÓN -> IMPRIME EN CONSOLA Y DEVUELVE 500
        print("**************************************************")
        print("  ERROR FATAL EN /practicantes/match (HTTP 500)")
        print(f"  Detalle de la excepción: {e}")
        traceback.print_exc() # Imprime el traceback completo para debugging
        print("**************************************************")
        raise HTTPException(status_code=500, detail="Error interno grave al procesar la coincidencia. Verifique logs del servidor para ver el 'traceback'.")

# =========================================
# 7. GET (OPCIONAL): OBTENER IMAGEN DE HISTORIAL
# =========================================
# Si necesitas ver la imagen guardada
@router.get("/imagen_historial/{historial_id}")
def get_historial_image(historial_id: int, db: Session = Depends(get_db)):
    registro = db.query(HistorialBiometricoModel).filter(
        HistorialBiometricoModel.id == historial_id
    ).first()

    if not registro or not registro.contenido_imagen:
        raise HTTPException(status_code=404, detail="Imagen no encontrada o registro no existe")

    # Retorna la imagen como respuesta binaria
    from fastapi.responses import Response
    return Response(content=registro.contenido_imagen, media_type="image/jpeg")


    # =========================================
# 8. APP MÓVIL: HISTORIAL DE ASISTENCIAS
# =========================================
@router.get("/asistencias")
def get_historial_asistencias(db: Session = Depends(get_db)):
    """
    Devuelve la lista de asistencias de todos los practicantes,
    incluyendo el nombre del practicante.
    """
    try:
        # Consulta: Usa joinedload para cargar la relación 'practicante' y acceder a su nombre.
        registros = db.query(Asistencia).options(
            joinedload(Asistencia.practicante) 
        ).order_by(
            Asistencia.timestamp_evento.desc()
        ).all()

        lista = [
            {
                "id": r.id,
                "practicante_id": r.practicante_id,
                # <<< AHORA INCLUYE EL NOMBRE DEL PRACTICANTE >>>
                "practicante_nombre": r.practicante.nombre, 
                "tipo_evento": r.tipo_evento,
                "timestamp_evento": r.timestamp_evento.isoformat()
            }
            for r in registros
        ]

        return JSONResponse(content=lista)

    except Exception as e:
        print(f"Error al obtener historial de asistencias: {e}")
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail="Error al obtener historial de asistencias. Revise logs del servidor."
        )