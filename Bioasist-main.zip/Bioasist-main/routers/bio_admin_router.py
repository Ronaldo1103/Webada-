from fastapi import APIRouter, Depends, HTTPException, Form, status
from sqlalchemy.orm import Session
from datetime import datetime

from db.database import get_db
from db.models import PracticanteDB, HistorialBiometricoDB, RostroBiometricoDB

router = APIRouter(
    prefix="/practicantes/admin",
    tags=["biometria_admin"]
)

# =================================================================
# 1️⃣ OBTENER LISTA DE PRACTICANTES (para el select del frontend)
# =================================================================
@router.get("/lista_practicantes")
def obtener_lista_practicantes(db: Session = Depends(get_db)):
    practicantes = db.query(PracticanteDB.id, PracticanteDB.nombre_completo).filter(
        PracticanteDB.activo == True
    ).all()

    lista = [
        {"id": p.id, "nombre_completo": p.nombre_completo}
        for p in practicantes
    ]
    return {"practicantes": lista}


# =================================================================
# 2️⃣ LISTAR HISTORIAL PENDIENTE DE VALIDAR
# =================================================================
@router.get("/historial_pendientes")
def listar_historial_pendientes(db: Session = Depends(get_db)):
    """
    Devuelve los registros del historial que aún no han sido asignados a un practicante.
    """
    # Filtramos los que no están en rostros_biometricos
    subquery = db.query(RostroBiometricoDB.historial_id)
    pendientes = db.query(HistorialBiometricoDB).filter(
        ~HistorialBiometricoDB.id.in_(subquery)
    ).all()

    registros = [
        {
            "historial_id": h.id,
            "nombre_sugerido": h.nombre_sugerido,
            "fecha_registro": h.fecha_registro.strftime("%Y-%m-%d %H:%M:%S"),
        }
        for h in pendientes
    ]
    return {"registros": registros}


# =================================================================
# 3️⃣ VINCULAR UN ROSTRO DE HISTORIAL A UN PRACTICANTE
# =================================================================
@router.post("/vincular_rostro")
def vincular_rostro(
    practicante_id: int = Form(...),
    historial_id: int = Form(...),
    db: Session = Depends(get_db)
):
    """
    Toma el vector biométrico (BLOB) del historial y lo inserta en rostros_biometricos.
    """
    # 1. Verificar existencia del practicante
    practicante = db.query(PracticanteDB).filter_by(id=practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado.")

    # 2. Verificar existencia del historial
    historial = db.query(HistorialBiometricoDB).filter_by(id=historial_id).first()
    if not historial:
        raise HTTPException(status_code=404, detail="Historial no encontrado.")

    # 3. Crear nuevo registro en rostros_biometricos
    nuevo_rostro = RostroBiometricoDB(
        practicante_id=practicante.id,
        historial_id=historial.id,
        vector_biometrico=historial.vector_biometrico,  # el BLOB se copia directo
        fecha_registro=datetime.now()
    )

    db.add(nuevo_rostro)
    db.commit()

    return {
        "mensaje": f"Rostro vinculado correctamente al practicante {practicante.nombre_completo}.",
        "practicante_id": practicante.id,
        "historial_id": historial.id
    }
