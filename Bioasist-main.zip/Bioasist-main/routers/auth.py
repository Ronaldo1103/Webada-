from fastapi import APIRouter, Depends, HTTPException, status, Form
from pydantic import BaseModel
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer

from db.database import get_db
from db.models import Usuario, Role

router = APIRouter(prefix="/api/auth", tags=["Auth"])

# ------------------- CONFIG -------------------
SECRET_KEY = "CAMBIAME_A_UN_SECRETO_LARGO_Y_UNICO"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 horas

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ------------------- SCHEMAS -------------------
class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    rol: str


# ------------------- UTILS -------------------
def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_access_token(data: dict):
    data = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    data.update({"exp": expire})
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


# ------------------- LOGIN -------------------
@router.post("/login", response_model=LoginResponse)
def login(credentials: LoginRequest, db: Session = Depends(get_db)):

    user = db.query(Usuario).filter(Usuario.username == credentials.username).first()

    if not user or not verify_password(credentials.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas"
        )

    token = create_access_token({
        "sub": user.username,
        "rol": user.rol.nombre
    })

    return LoginResponse(access_token=token, rol=user.rol.nombre)


# ------------------- GET CURRENT USER (ARREGLADO) -------------------
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
    except:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")

    user = db.query(Usuario).filter(Usuario.username == username).first()
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no encontrado")

    return user


# ------------------- ROLE CHECK -------------------
def require_role(required_role: str):
    def wrapper(user: Usuario = Depends(get_current_user)):
        if user.rol.nombre != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Acceso denegado. Se requiere rol '{required_role}'"
            )
        return user
    return wrapper


# ------------------- CREAR USUARIO -------------------
@router.post("/crear-usuario")
def crear_usuario(
    username: str = Form(...),
    password: str = Form(...),
    rol_nombre: str = Form(...),
    db: Session = Depends(get_db)
):

    if db.query(Usuario).filter(Usuario.username == username).first():
        raise HTTPException(status_code=400, detail="Usuario ya existe")

    hashed_password = pwd_context.hash(password)

    rol = db.query(Role).filter(Role.nombre == rol_nombre).first()
    if not rol:
        raise HTTPException(status_code=400, detail="Rol no encontrado")

    nuevo_usuario = Usuario(username=username, password=hashed_password, rol=rol)
    db.add(nuevo_usuario)
    db.commit()
    db.refresh(nuevo_usuario)

    return {"msg": f"Usuario {username} creado con rol {rol_nombre}"}
