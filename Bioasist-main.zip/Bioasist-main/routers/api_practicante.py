from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from typing import List

# Definimos el modelo de datos (Schema) para un Practicante
# (Normalmente esto estaría en 'models/practicante.py')
class Practicante(BaseModel):
    id: int | None = None
    nombre: str
    apellido: str
    email: str
    activo: bool = True
    
    class Config:
        # Permite que el modelo Pydantic pueda ser creado a partir de atributos (ORM mode)
        from_attributes = True

# Inicializamos el APIRouter
router = APIRouter(
    prefix="/api/practicantes", # Prefijo para todas las rutas en este archivo
    tags=["Practicantes API (JSON)"] # Etiqueta para la documentación de Swagger
)

# --- Base de datos simulada (Reemplazar con lógica de SQL/SQLite) ---
practicantes_db = [
    Practicante(id=1, nombre="Ana", apellido="Gomez", email="ana@uni.com"),
    Practicante(id=2, nombre="Luis", apellido="Perez", email="luis@uni.com", activo=False),
]
next_id = 3
# --------------------------------------------------------------------

# Endpoint GET: Obtener todos los practicantes (para Flutter/JSON)
@router.get("/", response_model=List[Practicante])
async def get_all_practicantes():
    """Retorna la lista completa de practicantes."""
    return practicantes_db

# Endpoint GET: Obtener un practicante por ID
@router.get("/{practicante_id}", response_model=Practicante)
async def get_practicante(practicante_id: int):
    """Retorna un practicante específico por su ID."""
    try:
        return next(p for p in practicantes_db if p.id == practicante_id)
    except StopIteration:
        raise HTTPException(status_code=404, detail="Practicante no encontrado")

# Endpoint POST: Crear un nuevo practicante
@router.post("/", response_model=Practicante, status_code=status.HTTP_201_CREATED)
async def create_practicante(practicante: Practicante):
    """Crea un nuevo practicante en la base de datos."""
    global next_id
    practicante.id = next_id
    practicantes_db.append(practicante)
    next_id += 1
    return practicante
