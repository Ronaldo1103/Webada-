from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import or_
from datetime import datetime
import pytz


from fastapi import Request
from datetime import datetime, timedelta, date   # <-- AGREGA date AQUÍ


# Se asume que database.py y models.py son accesibles
from db.database import get_db
from db.models import UniversidadModel, PracticanteDB, RostroBiometricoModel, HistorialBiometricoModel, Asistencia

zona_lima = pytz.timezone("America/Lima")
ahora = datetime.now(zona_lima)
# ================================
# 📘 1. Esquemas Pydantic
# ================================
class UniversidadCreate(BaseModel):
    nombre: str
    siglas: str

class UniversidadResponse(UniversidadCreate):
    id: int
    class Config:
        from_attributes = True


class PracticanteCreate(BaseModel):
    nombre: str
    apellido: str
    email: EmailStr
    universidad_id: int
    activo: Optional[bool] = True

class PracticanteResponse(PracticanteCreate):
    id: int
    class Config:
        from_attributes = True


class RostroVinculacion(BaseModel):
    # Usado para el endpoint de aprobación manual de rostros posteriores
    practicante_id: int
    historial_id: int


# ================================
# 🚀 2. Inicialización del router
# ================================
router = APIRouter(
    prefix="/api/admin",
    tags=["admin_gestion_db"]
)


# ================================
# 🎓 3. Endpoints de Universidades (Sin cambios)
# ================================
@router.post("/universidades", response_model=UniversidadResponse, status_code=status.HTTP_201_CREATED)
def create_university(uni_data: UniversidadCreate, db: Session = Depends(get_db)):
    existing_uni = db.query(UniversidadModel).filter(
        or_(
            UniversidadModel.nombre == uni_data.nombre,
            UniversidadModel.siglas == uni_data.siglas
        )
    ).first()

    if existing_uni:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ya existe una universidad con ese nombre o siglas."
        )

    db_uni = UniversidadModel(**uni_data.model_dump())
    db.add(db_uni)
    db.commit()
    db.refresh(db_uni)
    return db_uni


@router.get("/universidades", response_model=List[UniversidadResponse])
def read_universities(db: Session = Depends(get_db)):
    return db.query(UniversidadModel).order_by(UniversidadModel.nombre).all()


# ================================
# 👨‍🎓 4. Endpoints de Practicantes (Corregido y Clarificado)
# ================================
@router.post("/practicantes", response_model=PracticanteResponse, status_code=status.HTTP_201_CREATED)
def create_practicante(practicante_data: PracticanteCreate, db: Session = Depends(get_db)):
    # 1. Verificar universidad
    uni_exists = db.query(UniversidadModel).filter(UniversidadModel.id == practicante_data.universidad_id).first()
    if not uni_exists:
        raise HTTPException(
            status_code=404,
            detail=f"Universidad con ID {practicante_data.universidad_id} no encontrada."
        )

    # 2. Verificar correo único
    email_exists = db.query(PracticanteDB).filter(PracticanteDB.email == practicante_data.email).first()
    if email_exists:
        raise HTTPException(
            status_code=400,
            detail=f"Ya existe un practicante registrado con el correo: {practicante_data.email}"
        )

    # 3. Crear el practicante
    db_practicante = PracticanteDB(
        nombre=practicante_data.nombre,
        apellido=practicante_data.apellido,
        email=practicante_data.email,
        universidad_id=practicante_data.universidad_id,
        activo=practicante_data.activo
    )

    db.add(db_practicante)
    db.commit()
    db.refresh(db_practicante)

    return db_practicante

# ================================
# 📋 5. Listado de practicantes (Sin cambios)
# ================================
# ================================
# 📋 5. Listado de practicantes (CORREGIDO)
# ================================
@router.get("/practicantes") # <--- Renombrado de /lista_practicantes a /practicantes
def read_practicantes_with_details(db: Session = Depends(get_db)):
    practicantes_data = (
        db.query(PracticanteDB, UniversidadModel)
        .join(UniversidadModel, PracticanteDB.universidad_id == UniversidadModel.id)
        .all()
    )

    lista_practicantes = []
    for practicante, universidad in practicantes_data:
        
        # Verificar si tiene un rostro biométrico asociado
        tiene_rostro = db.query(RostroBiometricoModel).filter(RostroBiometricoModel.practicante_id == practicante.id).first() is not None
        
        lista_practicantes.append({
        "id": practicante.id,
        "nombre": practicante.nombre,
        "apellido": practicante.apellido,
        "email": practicante.email,
        "activo": practicante.activo,
        "universidad_id": universidad.id,
        "universidad_nombre": universidad.nombre,
        "universidad_siglas": universidad.siglas,
        "tiene_rostro": tiene_rostro,
        "total_vectores": db.query(RostroBiometricoModel).filter(
            RostroBiometricoModel.practicante_id == practicante.id
        ).count()
    })


    # El frontend espera una lista directamente, no un diccionario con clave 'practicantes'
    return lista_practicantes

# ================================
# 👁‍🗨 6. Endpoints de Historial y Vinculación (Flujo de Aprobación Manual)
# ================================

@router.get("/historial_pendientes")
def get_pending_historial(db: Session = Depends(get_db)):
    # Los registros pendientes son capturas posteriores que se han guardado en HistorialBiometrico
    # pero que aún no han sido aprobadas creando un RostroBiometrico.
    registros_pendientes = (
        db.query(HistorialBiometricoModel)
        .outerjoin(RostroBiometricoModel, HistorialBiometricoModel.id == RostroBiometricoModel.historial_id)
        .filter(RostroBiometricoModel.historial_id.is_(None))
        .all()
    )
    
    lista = [
        {
            "historial_id": r.id,
            "nombre_sugerido": r.nombre_sugerido,
            "fecha_registro": r.fecha_registro.strftime("%Y-%m-%d %H:%M:%S")
        }
        for r in registros_pendientes
    ]
    
    return {"registros": lista}


@router.post("/vincular_rostro", status_code=status.HTTP_200_OK)
def vincular_rostro(data: RostroVinculacion, db: Session = Depends(get_db)):
    # Este endpoint es para la APROBACIÓN MANUAL de un registro en el historial
    # a un practicante existente. NO es para el registro inicial.
    
    # 1. Verificar Historial
    historial = db.query(HistorialBiometricoModel).filter(HistorialBiometricoModel.id == data.historial_id).first()
    if not historial:
        raise HTTPException(status_code=404, detail="ID de historial no encontrado.")
    
    # 2. Verificar Practicante
    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == data.practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="ID de practicante no encontrado.")

    # 3. Verificar si ya fue vinculado (Historial debe ser único en RostroBiometrico)
    existing_rostro = db.query(RostroBiometricoModel).filter(RostroBiometricoModel.historial_id == data.historial_id).first()
    if existing_rostro:
        raise HTTPException(status_code=400, detail="Este rostro ya fue aprobado y vinculado.")

    # 4. Crear el nuevo registro de Rostro Biométrico (Aprobación)
    nuevo_rostro = RostroBiometricoModel(
        practicante_id=data.practicante_id,
        historial_id=data.historial_id,
        vector_biometrico=historial.vector_biometrico  # Usar el vector del historial
    )
    
    db.add(nuevo_rostro)
    db.commit()
    
    return {"message": f"Rostro del historial {data.historial_id} vinculado con éxito al practicante {practicante.nombre} {practicante.apellido}"}



@router.put("/practicantes/{practicante_id}", response_model=PracticanteResponse)
def update_practicante(practicante_id: int, data: PracticanteCreate, db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado.")

    practicante.nombre = data.nombre
    practicante.apellido = data.apellido
    practicante.email = data.email
    practicante.universidad_id = data.universidad_id
    practicante.activo = data.activo

    db.commit()
    db.refresh(practicante)

    return practicante


@router.patch("/practicantes/{practicante_id}/desactivar")
def desactivar_practicante(practicante_id: int, db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado.")

    practicante.activo = False
    db.commit()

    return {"message": "Practicante desactivado correctamente"}


@router.patch("/practicantes/{practicante_id}/activar")
def activar_practicante(practicante_id: int, db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado.")

    practicante.activo = True
    db.commit()

    return {"message": "Practicante activado correctamente"}


@router.delete("/practicantes/{practicante_id}")
def eliminar_practicante(practicante_id: int, db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado.")

    db.delete(practicante)
    db.commit()

    return {"message": "Practicante eliminado permanentemente"}


#asignar vector
@router.post("/asignar_vector", status_code=status.HTTP_201_CREATED)
def asignar_vector(
    data: RostroVinculacion,
    db: Session = Depends(get_db)
):
    # Validar practicante
    practicante = db.query(PracticanteDB).filter_by(id=data.practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado")

    # Validar historial
    historial = db.query(HistorialBiometricoModel).filter_by(id=data.historial_id).first()
    if not historial:
        raise HTTPException(status_code=404, detail="Historial no encontrado")

    # Crear vector (permite múltiples registros por practicante)
    nuevo_vector = RostroBiometricoModel(
        practicante_id = data.practicante_id,
        historial_id = data.historial_id,
        vector_biometrico = historial.vector_biometrico
    )

    db.add(nuevo_vector)
    db.commit()
    db.refresh(nuevo_vector)

    return {
        "mensaje": "Vector asignado correctamente",
        "vector_id": nuevo_vector.id
    }


# ================================
# 📌 7. Obtener vectores usados por un practicante
# ================================
@router.get("/vectores/{practicante_id}")
def obtener_vectores_practicante(practicante_id: int, db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter(PracticanteDB.id == practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado")

    vectores = (
        db.query(RostroBiometricoModel, HistorialBiometricoModel)
        .join(HistorialBiometricoModel, RostroBiometricoModel.historial_id == HistorialBiometricoModel.id)
        .filter(RostroBiometricoModel.practicante_id == practicante_id)
        .all()
    )

    resultado = []
    for rostro, historial in vectores:
        resultado.append({
            "id": rostro.id,
            "historial_id": historial.id,
            "nombre_sugerido": historial.nombre_sugerido,
            "fecha_registro": historial.fecha_registro.strftime("%Y-%m-%d %H:%M:%S")
        })

    return {"vectores": resultado}
# ================================
# 📌 8. Quitar un vector del practicante
# ================================
class QuitarVector(BaseModel):
    practicante_id: int
    vector_id: int

@router.post("/quitar_vector")
def quitar_vector(data: QuitarVector, db: Session = Depends(get_db)):

    vector = db.query(RostroBiometricoModel).filter(
        RostroBiometricoModel.id == data.vector_id,
        RostroBiometricoModel.practicante_id == data.practicante_id
    ).first()

    if not vector:
        raise HTTPException(status_code=404, detail="Vector no encontrado")

    db.delete(vector)
    db.commit()

    return {"message": "Vector eliminado correctamente"}


from datetime import datetime, timedelta

# ============================================================
# 📌 9. REPORTE DETALLADO DE ASISTENCIAS
# ============================================================
@router.get("/reporte_detallado/{practicante_id}")
def reporte_detallado(practicante_id: int,
                      inicio: Optional[str] = None,
                      fin: Optional[str] = None,
                      db: Session = Depends(get_db)):

    practicante = db.query(PracticanteDB).filter_by(id=practicante_id).first()
    if not practicante:
        raise HTTPException(status_code=404, detail="Practicante no encontrado")

    # -----------------------------------------
    # 🔹 Convertir fechas
    # -----------------------------------------
    try:
        fecha_inicio = datetime.strptime(inicio, "%Y-%m-%d") if inicio else None
        fecha_fin = datetime.strptime(fin, "%Y-%m-%d") if fin else None
    except:
        raise HTTPException(status_code=400, detail="Formato de fecha inválido. Use YYYY-MM-DD.")

    # -----------------------------------------
    # 🔹 Consulta base
    # -----------------------------------------
    query = db.query(Asistencia).filter(Asistencia.practicante_id == practicante_id)

    if fecha_inicio:
        query = query.filter(Asistencia.timestamp_evento >= fecha_inicio)

    if fecha_fin:
        # se incluye todo el día "fin"
        query = query.filter(Asistencia.timestamp_evento < fecha_fin + timedelta(days=1))

    eventos = query.order_by(Asistencia.timestamp_evento.asc()).all()

    # -----------------------------------------
    # 🔹 Procesar por cada día
    # -----------------------------------------
    reporte = {}
    for e in eventos:
        fecha = e.timestamp_evento.date()
        if fecha not in reporte:
            reporte[fecha] = {"entrada": None, "salida": None}

        if e.tipo_evento == "entrada" and reporte[fecha]["entrada"] is None:
            reporte[fecha]["entrada"] = e.timestamp_evento

        if e.tipo_evento == "salida":
            reporte[fecha]["salida"] = e.timestamp_evento

    # -----------------------------------------
    # 🔹 Construir lista final
    # -----------------------------------------
    resultado = []
    total_horas = 0
    total_asistencias = 0

    for fecha, data in sorted(reporte.items()):
        entrada = data["entrada"]
        salida = data["salida"]

        # Cálculo de horas
        if entrada and salida:
            horas = round((salida - entrada).total_seconds() / 3600, 2)
            estado = "Asistió"
            total_asistencias += 1
            total_horas += horas

        elif entrada and not salida:
            horas = 0
            estado = "Sin salida"
            total_asistencias += 1

        else:
            horas = 0
            estado = "Incompleto"

        resultado.append({
            "fecha": fecha.strftime("%Y-%m-%d"),
            "entrada": entrada.strftime("%H:%M:%S") if entrada else None,
            "salida": salida.strftime("%H:%M:%S") if salida else None,
            "horas": horas,
            "estado": estado
        })

    return {
        "practicante": {
            "id": practicante.id,
            "nombre": practicante.nombre,
            "apellido": practicante.apellido
        },
        "reporte": resultado,
        "total_horas": round(total_horas, 2),
        "total_asistencias": total_asistencias
    }


@router.get("/reporte_detallado_page/{practicante_id}")
def pagina_reporte_detallado(
    practicante_id: int,
    db: Session = Depends(get_db),
    request: Request = None
):

    practicante = db.query(PracticanteDB).filter_by(id=practicante_id).first()
    if not practicante:
        raise HTTPException(404, "Practicante no encontrado")

    # ================================
    # 1. CARGAR ASISTENCIAS DEL PRACTICANTE
    # ================================
    asistencias = (
        db.query(Asistencia)
        .filter(Asistencia.practicante_id == practicante_id)
        .order_by(Asistencia.timestamp_evento.desc())
        .all()
    )

    asistencias_data = []
    conteo_por_dia = {}

    for a in asistencias:
        fecha_str = a.timestamp_evento.date().isoformat()

        if fecha_str not in conteo_por_dia:
            conteo_por_dia[fecha_str] = 0

        if a.tipo_evento == "entrada":
            conteo_por_dia[fecha_str] += 1

        asistencias_data.append({
            "practicante": f"{practicante.nombre} {practicante.apellido}",
            "universidad": practicante.universidad.nombre if practicante.universidad else "No registra",
            "tipo": a.tipo_evento,
            "hora": a.timestamp_evento.strftime("%H:%M:%S"),
            "llego_tarde": a.llego_tarde
        })

    dias = list(conteo_por_dia.keys())
    asistencias_por_dia = list(conteo_por_dia.values())


    # ================================
    # 2. MÉTRICAS
    # ================================
    total_practicantes = db.query(PracticanteDB).count()
    total_asistencias = len(asistencias)

    hoy = date.today()

    entradas_hoy = (
        db.query(Asistencia)
        .filter(
            Asistencia.practicante_id == practicante_id,
            Asistencia.tipo_evento == "entrada",
            Asistencia.timestamp_evento >= hoy
        )
        .count()
    )

    salidas_hoy = (
        db.query(Asistencia)
        .filter(
            Asistencia.practicante_id == practicante_id,
            Asistencia.tipo_evento == "salida",
            Asistencia.timestamp_evento >= hoy
        )
        .count()
    )

    return templates.TemplateResponse(
        "reporte_detallado.html",
        {
            "request": request,
            "asistencias": asistencias_data,
            "dias": dias,
            "asistencias_por_dia": asistencias_por_dia,
            "total_practicantes": total_practicantes,
            "total_asistencias": total_asistencias,
            "entradas_hoy": entradas_hoy,
            "salidas_hoy": salidas_hoy,
        }
    )

