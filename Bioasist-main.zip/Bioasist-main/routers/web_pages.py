from fastapi import APIRouter, Request, Form, Depends, HTTPException, status
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
# Importamos Usuario (asumiendo que está corregido a role_id en db/models.py)
from db.models import Usuario 
from db.database import get_db
import bcrypt

router = APIRouter(prefix="/web", tags=["Web Pages"])
templates = Jinja2Templates(directory="templates")

# Constantes de Rol (1 es Admin, 2 es Practicante)
ROLE_ADMIN_ID = 1
ROLE_PRACTICANTE_ID = 2


# --- Auth function (Limpia) ---
def authenticate_user_db(db: Session, username: str, password: str):
    """Verifica el usuario y la contraseña con bcrypt."""
    user = db.query(Usuario).filter(Usuario.username == username).first() 
    if not user:
        return None
    
    try:
        password_bytes = password.encode("utf-8")
        if bcrypt.checkpw(password_bytes, user.password.encode('utf-8')):
            return user
        else:
            return None
            
    except Exception:
        return None


# --- Cookies user ---
def get_current_user(request: Request, db: Session = Depends(get_db)):
    """Obtiene la información del usuario de la DB basada en la cookie 'username'."""
    username = request.cookies.get("username")
    if not username:
        return None
    
    return db.query(Usuario).filter(Usuario.username == username).first()


# --- Require role (Usa ID 1 para Admin) ---
def require_role(role_id_required: int):
    """Decorator para proteger rutas basado en el role_id."""
    def wrapper(request: Request, db: Session = Depends(get_db)):
        user = get_current_user(request, db)
        user_role_id = getattr(user, 'role_id', None) 
        
        if not user or user_role_id != role_id_required:
            raise HTTPException(
                status_code=status.HTTP_303_SEE_OTHER,
                detail="No autorizado o rol incorrecto. Redirigiendo a login.",
                headers={"Location": "/web/login"} 
            )
            
        return user
    return wrapper

# --- Redirect root ---
@router.get("/", include_in_schema=False)
def root_redirect():
    return RedirectResponse(url="/web/login", status_code=303)


# --- Login GET ---
@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


# --- Login POST ---
@router.post("/login")
def login_post(request: Request, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = authenticate_user_db(db, username, password)

    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Usuario o contraseña incorrectos"})

    # Usamos el role_id del usuario para determinar la redirección
    user_role_id = getattr(user, 'role_id', ROLE_PRACTICANTE_ID)
    
    # 🚨 DEBUG CRÍTICO: Imprime el valor leído de la base de datos
    print(f"DEBUG: Rol ID LEÍDO de la DB para {username}: {user_role_id}")
    
    if user_role_id == ROLE_ADMIN_ID:
        # 🚨 Redirige al nuevo dashboard de gestión: /web/admin/gestion
        redirect_url = "/web/admin/gestion" 
        user_role_name = "admin"
    else:
        # Redirige al dashboard de practicante: /web/menu
        redirect_url = "/web/menu"
        user_role_name = "practicante"
    
    print(f"DEBUG: Redirección Final Elegida: {redirect_url}") 

    response = RedirectResponse(url=redirect_url, status_code=303)

    response.set_cookie("username", user.username, httponly=True, max_age=86400)
    response.set_cookie("role", user_role_name, httponly=True, max_age=86400)

    return response


# --- Logout ---
@router.get("/logout")
def logout():
    response = RedirectResponse(url="/web/login", status_code=303)
    response.delete_cookie("username")
    response.delete_cookie("role")
    return response


# --- Practicante Menu ---
@router.get("/menu", response_class=HTMLResponse)
def menu_page(request: Request, user=Depends(get_current_user)):
    if not user:
        return RedirectResponse(url="/web/login", status_code=303)
    # Carga la plantilla del practicante
    return templates.TemplateResponse("practicante_dashboard.html", {"request": request, "user": user})


# --- Admin Dashboard (Antigua) ---
@router.get("/admin", response_class=HTMLResponse)
def admin_page(request: Request, user=Depends(require_role(ROLE_ADMIN_ID))):
    """Ruta protegida para el dashboard principal (antiguo) del administrador."""
    return templates.TemplateResponse("admin_dashboard.html", {"request": request, "user": user})


# -----------------------------------------------------------------
# 🔑 DASHBOARD NUEVO: RUTA PREDETERMINADA DE REDIRECCIÓN
# -----------------------------------------------------------------
@router.get("/admin/gestion", name="gestion_practicantes")
async def gestion_practicantes_page(request: Request, db: Session = Depends(get_db)):
    """
    Renderiza la página de Gestión de Practicantes y Aprobación Biometrica.
    """
    
    # Aquí puedes añadir cualquier lógica de base de datos necesaria
    # Por ahora, los datos son cargados por JavaScript en el HTML

    return templates.TemplateResponse(
        # CRÍTICO: Usa el nombre de archivo final
        "gestion_practicantes.html", 
        {
            "request": request,
            # CRÍTICO: 'gestion_practicantes' debe coincidir con el if en tu base_admin.html
            "active_page": "gestion_practicantes", 
        }
    )


# --- Reporte Detallado ---
@router.get("/admin/reporte_detallado", response_class=HTMLResponse)
async def reporte_detallado_page(request: Request, user=Depends(require_role(ROLE_ADMIN_ID))):
    return templates.TemplateResponse(
        "reporte_detallado.html",
        {
            "request": request,
            "active_page": "reporte_detallado"
        }
    )
