from datetime import datetime, timedelta
import pytz

zona_lima = pytz.timezone("America/Lima")

def utc_to_lima(fecha_utc: datetime) -> datetime:
    """
    Convierte una fecha UTC a hora Lima.
    """
    if fecha_utc is None:
        return None
    if fecha_utc.tzinfo is None:
        # asumimos que es naive en UTC
        fecha_utc = fecha_utc.replace(tzinfo=pytz.UTC)
    return fecha_utc.astimezone(zona_lima)
