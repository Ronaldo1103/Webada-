from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from jose import jwt, JWTError
from db.database import get_db
from db.models import Usuario  # asegúrate que sea tu modelo de usuario
from routers.auth import SECRET_KEY, ALGORITHM

# Obtiene el usuario actual desde el token
def get_current_user(token: str = Depends(), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token.replace("Bearer ", ""), SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Token inválido")
    except JWTError:
        raise HTTPException(status_code=401, detail="Token inválido")
    
    user = db.query(Usuario).filter(Usuario.username == username).first()
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no encontrado")

    return user

# Valida rol del usuario
def require_role(role: str):
    def checker(user = Depends(get_current_user)):
        if user.role_id != role and getattr(user.role, "value", None) != role:
            raise HTTPException(status_code=403, detail="Acceso denegado")
        return user
    return checker
