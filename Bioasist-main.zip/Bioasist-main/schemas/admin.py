from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from db.database import get_db
from db.models import User, PracticanteDB, Asistencia, UserRole
from schemas.user import PracticanteSchema, PracticanteCreate, UserCreate, UserSchema

# Importamos las dependencias de autenticación para protección
from routers.auth import require_role 

router = APIRouter(
    prefix="/api/admin",
    tags=["Admin Management"],
    # Todas las rutas en este router REQUIEREN el rol 'admin'
    dependencies=[Depends(require_role("admin"))] 
)

# -----------------------------------------------------------------
# ENDPOINT 1: CREAR UN NUEVO PRACTICANTE (Registro Facial)
# -----------------------------------------------------------------
@router.post("/practicantes", response_model=PracticanteSchema, status_code=status.HTTP_201_CREATED)
async def create_practicante(
    practicante_data: PracticanteCreate, 
    db: Session = Depends(get_db)
):
    """
    Registra un nuevo practicante con su código biométrico (solo Admin).
    """
    db_practicante = PracticanteDB(
        nombre=practicante_data.nombre,
        codigo_rostro=practicante_data.codigo_rostro
    )
    db.add(db_practicante)
    db.commit()
    db.refresh(db_practicante)
    
    return db_practicante

# -----------------------------------------------------------------
# ENDPOINT 2: CREAR UN NUEVO USUARIO DE ACCESO (Login)
# -----------------------------------------------------------------
@router.post("/users", response_model=UserSchema, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate, 
    db: Session = Depends(get_db)
):
    """
    Crea una credencial de acceso (email/password) para Admin o Practicante (solo Admin).
    
    NOTA: Se asume que el practicante ya fue registrado con su rostro primero.
    """
    # 1. Verificar si el email ya existe
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado."
        )

    # 2. Crear el usuario
    # En un proyecto real, la contraseña debe ser hasheada aquí
    db_user = User(
        email=user_data.email,
        password=user_data.password, 
        rol=user_data.rol
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return db_user

# -----------------------------------------------------------------
# ENDPOINT 3: LISTAR TODOS LOS PRACTICANTES Y SUS HORAS
# -----------------------------------------------------------------
@router.get("/practicantes", response_model=List[PracticanteSchema])
async def list_practicantes(db: Session = Depends(get_db)):
    """
    Lista todos los practicantes registrados con sus asistencias (solo Admin).
    """
    # Carga las asistencias para evitar consultas N+1
    practicantes = db.query(PracticanteDB).all()
    return practicantes
