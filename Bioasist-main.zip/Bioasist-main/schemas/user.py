from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# Importamos el UserRole del modelo para la consistencia
from db.models import UserRole

# -----------------------------------------------------------------
# 1. ESQUEMAS PARA ASISTENCIA (Para mostrar en el dashboard)
# -----------------------------------------------------------------

class AsistenciaSchema(BaseModel):
    """Esquema de un registro de asistencia."""
    id: int
    timestamp_evento: datetime
    tipo_evento: str # 'entrada' o 'salida'

    class Config:
        from_attributes = True

# -----------------------------------------------------------------
# 2. ESQUEMAS PARA PRACTICANTES (Añadimos 'universidad' y cambiamos 'nombre')
# -----------------------------------------------------------------

class PracticanteBase(BaseModel):
    """Datos básicos del practicante (sin el código facial)."""
    # 🚨 CAMBIO: Usamos 'nombre_completo' y agregamos 'universidad'
    nombre_completo: str 
    universidad: str

class PracticanteCreate(PracticanteBase):
    """Datos necesarios para crear un nuevo registro biométrico."""
    codigo_rostro: str 

class PracticanteSchema(PracticanteBase):
    """Esquema completo del practicante para respuesta."""
    id: int
    fecha_registro: datetime
    
    # Relaciones que queremos cargar:
    asistencias: List[AsistenciaSchema] = [] 

    class Config:
        from_attributes = True
# -----------------------------------------------------------------
# 3. ESQUEMAS PARA USER (Para el login y creación de cuentas de acceso)
# -----------------------------------------------------------------

class UserBase(BaseModel):
    """Datos básicos de acceso."""
    email: EmailStr
    
class UserCreate(UserBase):
    """Datos necesarios para crear un nuevo usuario de login."""
    password: str # Se validará el hash en un proyecto real
    rol: UserRole = UserRole.practicante

class UserSchema(UserBase):
    """Esquema completo del usuario para respuesta."""
    id: int
    rol: UserRole
    practicante_id: Optional[int] = None # ID del practicante si lo es
    
    # Relación: si tiene datos de practicante asociados
    datos_practicante: Optional[PracticanteSchema] = None

    class Config:
        from_attributes = True
