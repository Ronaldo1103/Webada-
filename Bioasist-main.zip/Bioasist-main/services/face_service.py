# En: services/face_service.py

def buscar_coincidencia_rapida(db: Session, codigo_rostro_nuevo: str):
    """
    Busca el código más cercano en la DB.
    """
    # 1. Recuperar TODOS los códigos de la DB (en un entorno real, solo una vez en memoria)
    todos_practicantes = db.query(PracticanteDB).all()

    # 2. Convertir el código nuevo a formato numpy (vector)
    vector_nuevo = convertir_a_vector(codigo_rostro_nuevo)
    
    mejor_coincidencia = None
    min_distancia = 0.5 # Umbral de distancia (se ajusta experimentalmente)

    for practicante in todos_practicantes:
        vector_db = convertir_a_vector(practicante.codigo_rostro)
        
        # 3. Cálculo de Distancia (la clave de la IA)
        distancia = calcular_distancia_euclidiana(vector_nuevo, vector_db)
        
        if distancia < min_distancia:
            min_distancia = distancia
            mejor_coincidencia = practicante
            
    return mejor_coincidencia