from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import date, timedelta, datetime # Importamos datetime para la asistencia
# Asegúrate de importar TODOS los modelos necesarios
from db.models import PracticanteDB, Asistencia, HistorialBiometricoModel, RostroBiometricoModel, UniversidadModel 
from db.schemas import PracticanteSchema
from fastapi import HTTPException, status
import numpy as np
import cv2
import tensorflow as tf
import os
from pathlib import Path
import sys 
from db.models import Asistencia
from db.models import RostroBiometricoModel, HistorialBiometricoModel, PracticanteDB
from datetime import datetime, timezone



# =====================================================================
# ✅ CONFIGURACIÓN DE RUTAS Y CARGA GLOBAL DEL MODELO TFLITE
# =====================================================================
 
MODELO_FILENAME = "mobilefacenet_float32.tflite"
INPUT_SHAPE = (112, 112)
# Usamos Path.cwd() para asegurar que la ruta sea relativa al directorio de ejecución
BASE_DIR = Path.cwd() 
MODELO_PATH = str(BASE_DIR / 'ia_models' / MODELO_FILENAME)
 
TFLITE_INTERPRETER = None
INPUT_DETAILS = None
OUTPUT_DETAILS = None
FACE_CASCADE = None # Variable para el detector

# 1. Carga global del INTÉRPRETE de TFLite
try:
    TFLITE_INTERPRETER = tf.lite.Interpreter(model_path=MODELO_PATH)
    TFLITE_INTERPRETER.allocate_tensors()
    INPUT_DETAILS = TFLITE_INTERPRETER.get_input_details()
    OUTPUT_DETAILS = TFLITE_INTERPRETER.get_output_details()
    print(f"✅ TFLite Interpreter cargado exitosamente desde: {MODELO_PATH}")
 
except Exception as e:
    # Si la carga falla, TFLITE_INTERPRETER queda en None, y el error será manejado en extraer_codigo_biometrico.
    print(f"🚨 ERROR: No se pudo cargar el modelo TFLite. Verifique la ruta: {MODELO_PATH}. Detalles: {e}")
 
# =====================================================================
# ✅ CONFIGURACIÓN Y CARGA GLOBAL DEL DETECTOR FACIAL (Haar Cascade)
# =====================================================================
DETECTOR_FILENAME = "haarcascade_frontalface_default.xml" 
DETECTOR_PATH = str(BASE_DIR / 'ia_models' / DETECTOR_FILENAME) 
 
try:
    FACE_CASCADE = cv2.CascadeClassifier(DETECTOR_PATH)
    if FACE_CASCADE.empty():
        raise Exception(f"Clasificador Haar Cascade no cargado o ruta incorrecta: {DETECTOR_PATH}")
    print(f"✅ Detector Facial (Haar Cascade) cargado exitosamente.")
except Exception as e:
    print(f"🚨 ERROR: No se pudo cargar el detector facial. Detalles: {e}") 
    
# =====================================================================
# ⭐️ FUNCIÓN DE EXTRACCIÓN BIOMÉTRICA (RETORNA BYTES - SOLUCIÓN PARA BLOB)
# =====================================================================
def extraer_codigo_biometrico(contenido_imagen: bytes) -> bytes:
    """
    Procesa la imagen, detecta el rostro, extrae el vector (embedding) 
    y lo retorna en formato BYTES (BLOB).
    """
    if TFLITE_INTERPRETER is None or FACE_CASCADE is None:
          raise HTTPException(
              status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
              detail="Error de inicialización: Los modelos de IA no se cargaron correctamente en el servidor."
          )

    # --- 1. PROCESAMIENTO DE IMAGEN (OpenCV) ---
    nparr = np.frombuffer(contenido_imagen, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
 
    if img is None:
        raise ValueError("El archivo no es una imagen válida o está dañado.") 
 
    # Convertimos a RGB ya que cv2.imdecode puede cargarlo en BGR por defecto
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      
    # 2. Detectar rostros
    faces = FACE_CASCADE.detectMultiScale(
        gray_img, 
        scaleFactor=1.1, 
        minNeighbors=5, 
        minSize=(100, 100)
    )
 
    if len(faces) == 0:
        raise ValueError("Rostro no detectado en la imagen. Asegúrese de que su rostro esté claramente visible y de frente.")
 
    # 3. Seleccionar el rostro más grande
    (x, y, w, h) = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)[0]
 
    # 4. Recortar y pre-procesar el rostro para TFLite
    rostro_recortado = img_rgb[y:y+h, x:x+w] # Usamos el RGB
    rostro_listo = cv2.resize(rostro_recortado, INPUT_SHAPE) 
    rostro_listo = np.expand_dims(rostro_listo, axis=0)
    rostro_listo = rostro_listo.astype(np.float32) / 255.0
 
    # --- 5. EJECUCIÓN DEL MODELO (TFLite) ---
    try:
        TFLITE_INTERPRETER.set_tensor(INPUT_DETAILS[0]['index'], rostro_listo)
        TFLITE_INTERPRETER.invoke()
        vector_features = TFLITE_INTERPRETER.get_tensor(OUTPUT_DETAILS[0]['index'])[0]
          
        # 6. SERIALIZACIÓN CLAVE PARA BLOB: Convertir el vector NumPy a su representación BINARIA
        return vector_features.tobytes() 
          
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Fallo interno al ejecutar el modelo TFLite: {e}")


# =====================================================================
# ✅ FUNCIONES AUXILIARES DE DISTANCIA
# =====================================================================
# 🔑 FUNCIÓN FALTANTE #1
def distancia_coseno(a: np.ndarray, b: np.ndarray) -> float:
    """Calcula la similitud de coseno entre dos vectores normalizados."""
    dot_product = np.dot(a, b)
    # Asumimos que los vectores ya están normalizados por la función `normalizar`
    # Si no están normalizados: return dot_product / (np.linalg.norm(a) * np.linalg.norm(b))
    return dot_product

UMBRAL_COSENO = 0.65

def normalizar(v: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(v)
    return v / norm if norm != 0 else v

# =====================================================================
# ✅ FUNCIONES DE REGISTRO, VINCULACIÓN Y MATCHING
# =====================================================================

# --- Función de Registro en Historial ---
def crear_registro_en_historial(
    db: Session, 
    nombre: Optional[str], # Es opcional en el matching
    codigo_rostro: bytes,
    contenido_imagen: bytes # BLOB de la foto
) -> HistorialBiometricoModel:
    """
    Inserta el nombre sugerido, el vector biométrico y la imagen original en la tabla de historial 
    (HistorialBiometricoModel) para posterior validación y auditoría.
    """
    db_historial = HistorialBiometricoModel(
        nombre_sugerido=nombre,
        vector_biometrico=codigo_rostro, 
        imagen_original=contenido_imagen # Guardamos el BLOB de la imagen
    )
    db.add(db_historial)
    db.commit()
    db.refresh(db_historial)
    return db_historial

# --- Función de Vinculación (Lógica del Administrador) ---
def vincular_rostro_a_practicante(db: Session, practicante_id: int, historial_id: int) -> RostroBiometricoModel:
    """
    Crea un registro en RostroBiometricoModel tomando el vector del Historial.
    Esto es el paso de APROBACIÓN.
    """
    # 1. Obtener el registro de auditoría del historial
    registro_historial = db.query(HistorialBiometricoModel).filter(
        HistorialBiometricoModel.id == historial_id
    ).first()

    if not registro_historial:
        raise HTTPException(status_code=404, detail=f"Registro de historial ID {historial_id} no encontrado.")
    
    # 2. Opcional: Verificar si el historial ya fue vinculado (No hay un campo `historial_id` en `RostroBiometricoModel` 
    # en la estructura que inferí, pero asumiremos que el campo de enlace se llama así para la validación.)
    # Si no usas el campo historial_id en RostroBiometricoModel, ignora esta verificación.
    # if db.query(RostroBiometricoModel).filter(RostroBiometricoModel.historial_id == historial_id).first():
    #     raise HTTPException(status_code=409, detail=f"El registro de historial ID {historial_id} ya fue procesado y vinculado.")

    # 3. Crear el registro final en la tabla RostroBiometricoModel
    db_rostro = RostroBiometricoModel(
        practicante_id=practicante_id,
        # Si tienes este campo: historial_id=historial_id, 
        vector_biometrico=registro_historial.vector_biometrico # COPIAMOS EL BLOB DEL VECTOR
    )
    
    db.add(db_rostro)
    db.commit()
    db.refresh(db_rostro)
    return db_rostro

# --- Función de Matching (Identificación) ---
# 🔑 FUNCIÓN ADAPTADA: Renombrada a encontrar_coincidencia
def encontrar_coincidencia(db: Session, codigo_rostro_capturado: bytes) -> Optional[PracticanteDB]:
    """
    Compara el vector biométrico capturado con todos los vectores aprobados
    almacenados en la tabla RostroBiometricoModel y retorna el practicante
    si supera el umbral de similitud.
    """

    rostros_aprobados = db.query(RostroBiometricoModel).all()

    if not rostros_aprobados:
        print("⚠ No existen vectores biométricos aprobados en la base de datos.")
        return None

    # Convertir el rostro capturado a vector numpy y normalizar
    codigo_nuevo_np = normalizar(np.frombuffer(codigo_rostro_capturado, dtype=np.float32))

    mejor_match = None
    mayor_similitud = -1

    print("🔍 Iniciando comparación con registros biométricos...")

    for rostro in rostros_aprobados:
        vector_db_np = normalizar(np.frombuffer(rostro.vector_biometrico, dtype=np.float32))

        similitud = distancia_coseno(codigo_nuevo_np, vector_db_np)

        print(f"🧩 Comparando con practicante_id={rostro.practicante_id}, similitud={similitud}")

        if similitud > mayor_similitud:
            mayor_similitud = similitud
            mejor_match = rostro

    # Validación contra umbral
    if mejor_match and mayor_similitud >= UMBRAL_COSENO:
        print(f"🎯 MATCH EXITOSO → Practicante ID: {mejor_match.practicante_id} | Similitud: {mayor_similitud}")
        return db.query(PracticanteDB).filter_by(id=mejor_match.practicante_id).first()

    print(f"❌ Match NO encontrado. Similitud máxima: {mayor_similitud}")
    return None

# --- Función de Registro de Asistencia ---
# 🔑 FUNCIÓN FALTANTE #2
def registrar_asistencia(db: Session, practicante_id: int):
    """
    Registra automáticamente ENTRADA o SALIDA dependiendo del último registro.
    """

    # Obtener el último evento del practicante
    ultimo_evento = (
        db.query(Asistencia)
        .filter(Asistencia.practicante_id == practicante_id)
        .order_by(Asistencia.timestamp_evento.desc())
        .first()
    )

    # Determinar tipo de evento
    if ultimo_evento is None or ultimo_evento.tipo_evento == "salida":
        tipo_evento = "entrada"
    else:
        tipo_evento = "salida"

    # Crear el nuevo registro
    nuevo_registro = Asistencia(
        practicante_id=practicante_id,
        timestamp_evento=datetime.now(timezone.utc),
        tipo_evento=tipo_evento
    )

    db.add(nuevo_registro)
    db.commit()
    db.refresh(nuevo_registro)

    print(f"📌 Registro guardado: {tipo_evento.upper()} para practicante ID {practicante_id}")
    return True


# --- Funciones para obtener datos para dashboard (Se mantienen sin cambios grandes en su lógica) ---

def get_dashboard_stats(db: Session):
    """Obtiene las estadísticas clave del dashboard."""
    
    total_practicantes = db.query(PracticanteDB).count() 
    # ... (el resto del código de get_dashboard_stats se mantiene igual)
    asistencia_promedio = 93.5 
    
    # Asumimos que Asistencia tiene campo 'fecha' y 'estado'
    hace_7_dias = date.today() - timedelta(days=7)
    # Se recomienda usar el campo correcto si es TIMESTAMP
    tardanzas_7_dias = db.query(Asistencia).filter(
        Asistencia.timestamp_evento >= hace_7_dias,
        # Asistencia.tipo_evento == "Tarde" # Si tienes un campo de tipo evento
    ).count() # Solo contamos el número de registros en la última semana

    practicantes_con_faltas = 2 
    # Se asume que PracticanteDB tiene los campos nombre y apellido
    practicantes_list = db.query(PracticanteDB.nombre, PracticanteDB.apellido).limit(5).all() 
    mock_statuses = ["85% (3 Tardanzas)", "98% (Excelente)", "75% (Riesgo)", "95% (Puntual)", "91% (1 Falta)"]
    
    lista_estado = []
    for i, p in enumerate(practicantes_list):
        lista_estado.append({
            "nombre_completo": f"{p.nombre} {p.apellido}",
            "estado": mock_statuses[i % len(mock_statuses)]
        })
    
    return {
        "total_practicantes": total_practicantes,
        "asistencia_promedio": asistencia_promedio,
        "tardanzas_7_dias": tardanzas_7_dias,
        "practicantes_con_faltas": practicantes_con_faltas,
        "lista_practicantes": lista_estado
    }


def crear_practicante(db: Session, nombre: str, apellido: str, universidad_id: int):
    nuevo = PracticanteDB(
        nombre=nombre,
        apellido=apellido,
        universidad_id=universidad_id,
        nombre_completo=f"{nombre} {apellido}",
        activo=True
    )

    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return nuevo